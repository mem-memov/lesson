<?php
	// peace out
	header( "Location: login.php" );
